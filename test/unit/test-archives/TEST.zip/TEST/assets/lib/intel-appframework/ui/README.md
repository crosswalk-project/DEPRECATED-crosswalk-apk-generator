#App Framework UI

Cross platform mobile UI framework.  It currently targets Android 2.2+, iOS 4+, BB7+, WP8.

Please see the included kitchen sink demo.

Additional documentation can be found at http://app-framework-software.intel.com/documentation.php